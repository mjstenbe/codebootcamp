
public class Email {

	public static void main(String args){
		
		String email = "mika@sci.fi";
		
		if ( email.indexOf("@") > 0 )
			System.out.println("Oli kelvollinen!");
		
	}
	
}
