import java.util.Scanner;

public class Kertotaulu {

	public static void main(String[] args) {

		Scanner lukija = new Scanner(System.in);
		System.out.println("Anna luku: ");
		int luku = lukija.nextInt();

		for (int i = 1; i <= 20; i++) {
			//System.out.println(i + " kertaa " + luku + " = " + (i * luku));
			System.out.printf("%5d kertaa %5d = %5d \n", i, luku, luku * i);
		}

	}

}
