
public class Toistolauseita {

	public static void main(String[] args) {

		for (int laskuri = 0; laskuri < 10; laskuri++) {
			System.out.println("Hoi Maailma");
		}

		int laskuri = 0;
		while (laskuri < 10){
			System.out.println("Hoi Maailma");
		}
		
	}

}
