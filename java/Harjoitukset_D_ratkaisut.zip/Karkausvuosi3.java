import java.util.Scanner;

public class Karkausvuosi3 {
	public static void main(String args[]) {

		Scanner lukija = new Scanner(System.in);
		System.out.println("Anna vuosi: ");

		int vuosi = lukija.nextInt();

		if (vuosi < 1753) {
			System.out.println("Noudatettiin Juliaanista kalenteria!");
			if (vuosi % 4 == 0)
				System.out.println("Oli karkausvuosi!");
		} else {

			if (vuosi % 400 == 0) {
				System.out.println("Vuosi oli/on karkausvuosi.");
			}

			else if (vuosi % 4 == 0 && vuosi % 100 != 0) {
				System.out.println("Vuosi oli/on karkausvuosi.");
			}

			else {
				System.out.println("Vuosi ei ollut/ole karkausvuosi.");
			}

		}
	}
}
