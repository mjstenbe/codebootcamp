import java.util.Scanner;

public class Vertailua {

	public static void main(String[] args) {

		// � Jos ik� on alle 6 tulostetaan �Esikoululainen�
		// � Jos ik� on tasan 14 tulostetaan �Haastava ik�
		// � Jos ik� on 16 - 18 tulostetaan �L�hes aikuinen�
		// � Jos ik� on suurempi kuin 18, mutta pienempi kuin 30
		// tulostetaan,�Olet t�ysi-ik�inen, muttet viel� keski-i�n kriisiss�.
		// � Jos ik� on suurempi tai yht� suuri kuin 30, mutta pienempi kuin 45
		// tulostetaan:
		// �Olet keski-i�ss�
		// � Jos ik� on suurempi kuin 45 mutta alle 65 tulostetaan �Viel� ehtii
		// ennen el�kett�!�
		// � Muuten ohjelma tulostaa �Olet el�kel�inen�.

		Scanner lukija = new Scanner(System.in);
		int ik� = 0;

		System.out.println("Kuinka vanha olet: ");
		ik� = lukija.nextInt();

		// � Jos ik� on pienempi kuin 0 tai suurempi kuin 150, tulostetaan
		// �Virheellinen ik�!�

		if (ik� < 0 || ik� > 150) {
			System.out.println("Virheellinen ik�!");

		}

		// � Jos ik� on alle 6 tulostetaan �Esikoululainen�

		else if (ik� < 6) {
			System.out.println("Esikoululainen");
		}

		// // � Jos ik� on suurempi kuin 45 mutta alle 65 tulostetaan �Viel�
		// ehtii

		else if (ik� > 45 && ik� < 65) {
			System.out.println("Viel� ehtii!");
		}

		// // � Muuten ohjelma tulostaa �Olet el�kel�inen�.
		else {
			System.out.println("Olet el�kel�inen!");
		}

	}

}
