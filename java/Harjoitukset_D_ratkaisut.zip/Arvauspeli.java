import java.util.Scanner;

public class Arvauspeli {

	public static void main(String[] args) {

		// 1. Alkuarvon asetus

		int vastaus = 7;

		// 2. Sy�tteen lukeminen

		Scanner lukija = new Scanner(System.in);
		System.out.println("Anna luku: ");
		int luku = lukija.nextInt();

		// 3. Vertailu

		 
		
		if (luku == vastaus) {
			System.out.println("Oikein");
		} else {
			System.out.println("V��rin!");
			
			if (luku < vastaus) {
				System.out.println("Oli liian pieni");
			} 
			
			else {
				System.out.println("Oli liian suuri!");
			}
			
		}

		

	}
}