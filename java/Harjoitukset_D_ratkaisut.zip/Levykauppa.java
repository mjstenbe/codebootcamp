public class Levykauppa {

	public static void main(String[] args) {

		int rahaa = 110;

		while (rahaa >= 20) {
			rahaa -= 20;
			System.out.println("Ostettiin yksi levy. " + "Rahaa j�ljell�: "
					+ rahaa);
		}

		for (int rahaa2 = 110; rahaa2 >= 0; rahaa2 -= 20) {
			System.out.println("Ostettiin yksi levy. Rahaa j�ljell�: " + rahaa);
		}

	}

}
