import java.util.Scanner;

public class TunnusJaSalasana {

	public static void main(String[] args) {

		// 1. Alkuarvojen asetus

		String salasana = "SalaineN";
		String tunnus = "Matti";

		String syotettyTunnus = "";
		String syotettySalasana = "";

		// 2. Sy�tteen lukeminen

		Scanner lukija = new Scanner(System.in);

		do {
			System.out.println("Anna tunnus: ");
			syotettyTunnus = lukija.nextLine();

			System.out.println("Anna salasana: ");
			syotettySalasana = lukija.nextLine();

			// 3. Vertailu

			if (!syotettySalasana.equalsIgnoreCase(salasana)
					|| !syotettyTunnus.equalsIgnoreCase(tunnus)) {
				System.out.println("Tunnus tai salasana oli v��rin!");
			}

		} while (!syotettySalasana.equalsIgnoreCase(salasana)
				|| !syotettyTunnus.equalsIgnoreCase(tunnus));

		System.out.println("Oikein meni!");
	}
}
