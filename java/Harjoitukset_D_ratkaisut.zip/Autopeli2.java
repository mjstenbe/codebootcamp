import java.util.Scanner;

public class Autopeli2 {

	public static void main(String[] args) {

	int luku = 0 ;
	
	do{
		
		Scanner lukija = new Scanner(System.in);

		System.out.println("**********************");
		System.out.println("* 1 � K�ynnist� auto");
		System.out.println("* 2 � Aja autoa");
		System.out.println("* 3 � Sammuta auto");
		System.out.println("* 4 � Lopeta peli");
		System.out.println("**********************");

		System.out.println("Valintasi: ");
		luku = lukija.nextInt();

		switch (luku) {

		case 1:
			System.out.println("K�ynnistet��n auto!");
			break;

		case 2:
			System.out.println("Autoa ajetaan!");
			break;

		case 3:
			System.out.println("Sammutettiin");
			break;

		case 4:
			System.out.println("Peli loppui");
			break;

		default:
			System.out.println("Tuntematon komento!");
			break;

		}
		
	}while(luku != 4 );

	}
}
