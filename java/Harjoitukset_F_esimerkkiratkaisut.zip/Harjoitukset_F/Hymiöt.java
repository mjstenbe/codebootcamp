package Harjoitukset_F;

import java.util.Scanner;

public class Hymi�t {

	static String jono;

	public static void main(String[] args) {

		lueTeksti();
	}

	public static void lueTeksti() {
		Scanner lukija = new Scanner(System.in);

		System.out.println("Anna merkkijono: ");
		jono = lukija.nextLine();

		korvaaHymit();
		korvaahymit(" ");

	}

	public static void korvaaHymit() {
		String lol1 = "xD";
		String korvaaja = "*";

		String uusi = jono.replaceAll(lol1, korvaaja);
		System.out.println(uusi);

	}

	public static void korvaahymit(String korvaaja) {
		String lol1 = "xD";

		String uusi1 = jono.replaceAll(lol1, korvaaja);
		System.out.println(uusi1);
	}

}
