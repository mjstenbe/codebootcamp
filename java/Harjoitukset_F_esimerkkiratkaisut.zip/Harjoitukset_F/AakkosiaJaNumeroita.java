package Harjoitukset_F;

public class AakkosiaJaNumeroita {

	public static void main(String[] args) {

		tulostaAaakoset();
		tulostaNumerot();
		tulostaAaakoset();

	}

	public static void tulostaNumerot() {
		System.out.println("1234567890");
	}

	public static void tulostaAaakoset() {
		System.out.println("abcdefghijklmnopqrstu...");
	}

}
