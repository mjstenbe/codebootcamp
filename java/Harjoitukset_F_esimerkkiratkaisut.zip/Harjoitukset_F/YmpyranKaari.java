package Harjoitukset_F;

public class YmpyranKaari {

	public static void main(String[] args) {
		ympyrankaari(2.5);
	}

	public static void ympyrankaari(double sade) {

		double kaari = 2 * Math.PI * sade;
		System.out.println("Ympyr�nkaari on " + kaari);

	}

}
